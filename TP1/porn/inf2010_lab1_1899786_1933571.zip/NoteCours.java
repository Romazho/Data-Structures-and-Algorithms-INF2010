package POO;

public class NoteCours {
	NoteCours(String sigle, String titre, int note){
		this.sigle = sigle;
		this.titre = titre;
		this.note = note;
	}
	public String sigle;
	public String titre;
	public int note;	
}
   


